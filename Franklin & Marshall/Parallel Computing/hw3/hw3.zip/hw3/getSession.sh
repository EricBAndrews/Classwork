#!/bin/bash

interact -A cc3uv3p -p GPU-shared --gres=gpu:k80:1
