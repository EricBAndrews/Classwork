/*
For your openacc code
*/

const char* dgemm_desc = "OpenACC blocked dgemm";

/* This routine performs a dgemm operation
 *  C := C + A * B
 * where A, B, and C are lda-by-lda matrices stored in column-major format. 
 * On exit, A and B maintain their input values. */  
void square_dgemm (int lda, double* A, double* B, double* C)
{
  //Fill me
}
